#ifndef ELEPHANT_H
#define ELEPHANT_H
#include <iostream>
using namespace std;

const int SIZE = 10;
void Get_Elephant_Data(string[], float[]);
void Get_Stats(float[], float&, float&, int&);



#endif
